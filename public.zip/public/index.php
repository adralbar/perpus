<?php

use Illuminate\Foundation\Application;

// This file is used by the Laravel Framework to bootstrap the application.
// We will be starting the framework and handling the request here.

require __DIR__ . '/../vendor/autoload.php';

$app = require_once __DIR__ . '/../bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);

$response = $kernel->handle(
    $request = Illuminate\Http\Request::capture()
);

$response->send();

$kernel->terminate($request, $response);
